-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2023 at 09:16 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentresult`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbclass`
--

CREATE TABLE `tbclass` (
  `id` int(11) NOT NULL,
  `class_name` varchar(191) NOT NULL,
  `section` varchar(191) NOT NULL,
  `creation_date` date NOT NULL,
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbclass`
--

INSERT INTO `tbclass` (`id`, `class_name`, `section`, `creation_date`, `updation_date`) VALUES
(1, 'Information Technology', 'IT', '2023-08-10', '0000-00-00'),
(2, 'Account', 'Acc', '2023-08-18', '0000-00-00'),
(4, 'Electrician', 'EE', '2023-08-03', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbclass`
--
ALTER TABLE `tbclass`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbclass`
--
ALTER TABLE `tbclass`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
